import { createSlice } from "@reduxjs/toolkit";

const initialState = {};

const userSlice = createSlice({
  name: "userSlice",
  initialState,
  reducers: {
    showInfo: state => {
      console.log("사용자 정보 : ", state);
    },
  },
  // 비동기 즉, api 연동 작업 후 slice의 state 관리
  extraReducers: builder => {
    builder.addCase();
  },
});
export const { showInfo } = userSlice.actions;
export default userSlice.reducer;
